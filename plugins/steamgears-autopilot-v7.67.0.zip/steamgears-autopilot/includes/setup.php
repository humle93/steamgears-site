<?php
/**
 * Setup wizard, the tabbed Settings page and the "Get started" checklist.
 * Patterns from WooCommerce/WPForms/Rank Math onboarding: one decision per step,
 * choice cards and switches, an inline key test, and a checklist that lets you
 * finish later. Loaded from steamgears-autopilot.php.
 */

if (!defined('ABSPATH')) exit;

class SGAP_Setup {
    const STATE = 'sgap_setup_state';

    /** Friendly labels for setting keys. */
    const LABELS = [
        'autopilot_enabled' => 'Autopilot', 'full_auto_enabled' => 'Full auto (skip approval)', 'channels' => 'Channels',
        'posts_per_day' => 'Pages to promote per day', 'ai_provider' => 'AI provider', 'ai_api_key' => 'AI API key', 'ai_model' => 'AI model',
        'ai_base_url' => 'API base URL', 'content_language' => 'Article language', 'image_model' => 'Image model', 'image_api_key' => 'AIMLAPI key for images',
        'serpapi_key' => 'SerpApi key (keyword research)', 'publish_mode' => 'How posts reach Publer', 'publer_api_key' => 'Publer API key',
        'publer_workspace_id' => 'Publer workspace', 'publer_pinterest_board' => 'Pinterest board ID', 'daily_cap' => 'Max posts per day',
        'batch_size' => 'Posts per 15-minute run', 'quiet_start' => 'Quiet from', 'quiet_end' => 'Quiet until', 'labor_rate' => 'Your hourly rate',
        'monthly_budget' => 'Monthly budget', 'target_roi' => 'Target ROI %', 'winner_min_clicks' => 'Winner after clicks', 'loser_min_clicks' => 'Loser after clicks',
        'repost_cooldown_days' => 'Days before a page is promoted again', 'repost_max' => 'Max reposts', 'merchant_feed_secret' => 'Product feed secret',
        'evergreen_enabled' => 'Recycle evergreen pages', 'evergreen_after_days' => 'Days between two shares', 'evergreen_max_shares' => 'Default shares per page', 'evergreen_batch' => 'Pages recycled per day',
        'auto_images' => 'AI photos for Instagram & Pinterest', 'auto_seo' => 'SEO meta for new posts & products', 'articles_per_week' => 'SEO articles per week',
        'auto_publish_articles' => 'Publish weekly articles automatically', 'weekly_report' => 'Weekly e-mail report', 'rescue_hosts' => 'Copy images from these servers',
        'mcp_client_id' => 'MCP client ID', 'mcp_refresh_token' => 'MCP refresh token',
        'telegram_bot_token' => 'Bot token', 'bluesky_app_password' => 'App password', 'mastodon_token' => 'Access token',
        'printful_api_key' => 'Printful API token', 'printful_store_id' => 'Printful store ID', 'woo_min_margin' => 'Minimum margin %',
        'pinterest_client_id' => 'Pinterest App ID', 'pinterest_client_secret' => 'Pinterest app secret',
        'pinterest_access_token' => 'Pinterest access token', 'pinterest_refresh_token' => 'Pinterest refresh token',
        'instagram_user_id' => 'Instagram account ID', 'instagram_graph_host' => 'Graph host',
        'instagram_access_token' => 'Instagram access token',
        'facebook_access_token' => 'Facebook page token',
        'facebook_page_id' => 'Facebook page id',
        'forum_enabled' => 'Forum', 'forum_slug' => 'Forum address', 'forum_topics_per_page' => 'Threads per page', 'forum_intro' => 'Forum intro',
        'reddit_enabled' => 'Reddit', 'reddit_auto_share' => 'Share new threads automatically', 'reddit_default_sub' => 'Default subreddit',
        'reddit_radar_subs' => 'Radar subreddits', 'reddit_keywords' => 'Radar keywords', 'reddit_daily_cap' => 'Reddit posts per day',
        'reddit_min_words' => 'Words before a thread is shared', 'reddit_min_interval' => 'Minutes between two posts',
        'reddit_client_id' => 'Reddit app id', 'reddit_client_secret' => 'Reddit app secret', 'reddit_username' => 'Reddit username',
        'reddit_password' => 'Reddit password', 'reddit_refresh_token' => 'Reddit refresh token'
    ];

    /**
     * Settings page tabs: id => [label, icon, keys].
     *
     * The keys tab is first and owns every secret (SGAP_Settings::SECRET_KEYS); the other tabs
     * carry settings only. settings_page() strips a secret from any other panel as a guard, so a
     * key added to the wrong tab later still shows up in exactly one place.
     */
    const TABS = [
        'keys' => ['Keys', 'lock', ['publer_api_key', 'ai_api_key', 'image_api_key', 'serpapi_key', 'telegram_bot_token', 'merchant_feed_secret', 'bluesky_app_password', 'mastodon_token', 'mcp_refresh_token', 'printful_api_key', 'pinterest_access_token', 'pinterest_refresh_token', 'pinterest_client_secret', 'instagram_access_token', 'facebook_access_token', 'reddit_client_secret', 'reddit_password', 'reddit_refresh_token']],
        'basics' => ['Basics', 'admin-home', ['autopilot_enabled', 'full_auto_enabled', 'channels', 'posts_per_day']],
        'ai' => ['AI & images', 'superhero-alt', ['ai_profile', 'ai_provider', 'ai_model', 'ai_base_url', 'content_language', 'image_model']],
        'publishing' => ['Publishing', 'megaphone', ['publish_mode', 'publer_workspace_id', 'publer_pinterest_board', 'pinterest_client_id', 'instagram_user_id', 'instagram_graph_host', 'facebook_page_id', 'facebook_graph_version', 'facebook_direct', 'bluesky_handle', 'mastodon_instance', 'mastodon_limit', 'telegram_chat_id', 'quality_gate', 'banned_words', 'dupe_days']],
        'schedule' => ['Schedule & limits', 'clock', ['quiet_start', 'quiet_end', 'blackout_ranges', 'daily_cap', 'batch_size', 'repost_cooldown_days']],
        'evergreen' => ['Evergreen', 'update', ['evergreen_enabled', 'evergreen_after_days', 'evergreen_max_shares', 'evergreen_batch']],
        'shop' => ['Shop & feeds', 'cart', ['woo_min_margin']],
        'mcp' => ['MCP access', 'admin-links', ['mcp_client_id']],
        'automation' => ['Automation', 'update-alt', ['auto_images', 'auto_seo', 'articles_per_week', 'auto_publish_articles', 'weekly_report', 'rescue_hosts']],
        'advanced' => ['Economics', 'chart-line', ['labor_rate', 'monthly_budget', 'target_roi', 'winner_min_clicks', 'loser_min_clicks', 'repost_max']],
        'forum' => ['Forum & Reddit', 'admin-comments', ['forum_enabled', 'forum_slug', 'forum_topics_per_page', 'forum_intro',
            'reddit_enabled', 'reddit_auto_share', 'reddit_default_sub', 'reddit_radar_subs', 'reddit_keywords',
            'reddit_daily_cap', 'reddit_min_words', 'reddit_min_interval', 'reddit_client_id', 'reddit_username']]
    ];

    /**
     * One line per tab: what the tab decides. Every tab has a heading of its own, so a tab is
     * never a stack of unnamed fields — the keys tab speaks for itself and is therefore absent.
     */
    const TAB_HINTS = [
        'basics' => 'What the autopilot may do on its own, where it posts, and how many pages it promotes a day.',
        'ai' => 'Which model writes the posts, the articles and the images, and in which language.',
        'publishing' => 'How posts leave the site, which accounts they go to, and what the quality gate refuses.',
        'schedule' => 'When posts are released, how many per day, and the days when nothing goes out at all.',
        'evergreen' => 'Pages worth sharing more than once: how long between two shares, and how many each page gets.',
        'shop' => 'Printful\'s store, the product feed and the margin floor the shop tools may not undercut.',
        'mcp' => 'The client id the site uses when it renews its own MCP token.',
        'automation' => 'What runs by itself: AI images, SEO meta on new posts, weekly articles and the image rescue.',
        'advanced' => 'Your hourly rate and the numbers that decide whether a post is a winner, a loser or worth repeating.',
        'forum' => 'A forum for the questions the shop answers in public, and the Reddit account that gives the threads readers.'
    ];

    const CHANNEL_LABELS = [
        'facebook' => 'Facebook', 'instagram' => 'Instagram', 'pinterest' => 'Pinterest', 'linkedin' => 'LinkedIn', 'twitter' => 'X / Twitter',
        'threads' => 'Threads', 'bluesky' => 'Bluesky', 'mastodon' => 'Mastodon', 'telegram' => 'Telegram', 'google' => 'Google Business'
    ];

    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'menu'], 19);
        add_action('wp_ajax_sgap_setup_save', [__CLASS__, 'ajax_save']);
        add_action('wp_ajax_sgap_setup_test', [__CLASS__, 'ajax_test']);
    }

    public static function menu(): void {
        add_submenu_page('steamgears-autopilot', 'Setup', self::complete() ? 'Setup' : 'Setup <span class="awaiting-mod">!</span>', 'manage_options', 'sgap-setup', [__CLASS__, 'wizard'], 0);
    }

    public static function state(): array {
        $s = get_option(self::STATE);
        return is_array($s) ? $s + ['feeds_done' => [], 'finished' => false] : ['feeds_done' => [], 'finished' => false];
    }

    /* ---- checklist ---- */

    /** id => [done, title, how, link]. */
    public static function checklist(): array {
        global $wpdb;
        $keys = get_option(SGAP_KeyCheck::RESULT);
        $ai_ok = is_array($keys) && !empty($keys['ai']['ok']);
        $channels = SGAP_Publer::channels();
        $state = self::state();
        $feeds_ok = SGAP_RSS::enabled() ? ($channels && !array_diff($channels, (array) $state['feeds_done'])) : SGAP_Publer::configured();
        $drafts = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sgap_ai_drafts");
        $published = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sgap_queue WHERE status = 'published'");
        $setup = admin_url('admin.php?page=sgap-setup');
        return [
            'ai' => [$ai_ok, 'Connect the AI', 'Add your AIMLAPI or Claude key and test it.', $setup . '#step-ai'],
            'channels' => [(bool) $channels, 'Choose your channels', 'Where should posts go?', $setup . '#step-channels'],
            'publer' => [$feeds_ok, SGAP_RSS::enabled() ? 'Add the feeds in Publer' : 'Connect Publer', SGAP_RSS::enabled() ? 'One RSS feed per channel, set to Auto-post.' : 'Publer API key and workspace.', $setup . '#step-publer'],
            'autopilot' => [SGAP_Settings::enabled('autopilot_enabled'), 'Switch the autopilot on', 'Daily writing and publishing.', $setup . '#step-schedule'],
            'drafts' => [$drafts > 0, 'Generate your first posts', 'Let the AI write drafts for your pages.', admin_url('admin.php?page=steamgears-autopilot')],
            'published' => [$published > 0, 'Approve and publish one', 'Approve a draft and release the queue.', admin_url('admin.php?page=sgap-ai')]
        ];
    }

    public static function complete(): bool {
        foreach (self::checklist() as [$done]) {
            if (!$done) {
                return false;
            }
        }
        return true;
    }

    /** Dashboard card; hidden once everything is done. */
    public static function checklist_card(): void {
        $items = self::checklist();
        $done = count(array_filter($items, fn($i) => $i[0]));
        if ($done === count($items)) {
            return;
        }
        echo '<div class="sgap-card sgap-checklist"><div class="sgap-check-head"><h2><span class="dashicons dashicons-flag"></span>Get started</h2><span class="sgap-pill brass">'
            . esc_html("{$done} of " . count($items) . ' done') . '</span></div>'
            . '<div class="sgap-bar"><span style="width:' . (int) round(100 * $done / count($items)) . '%"></span></div><ol class="sgap-steps">';
        foreach ($items as [$ok, $title, $how, $link]) {
            echo '<li class="' . ($ok ? 'done' : '') . '"><span class="sgap-dot">' . ($ok ? '✓' : '') . '</span><div><strong>' . esc_html($title) . '</strong><span>' . esc_html($how) . '</span></div>'
                . ($ok ? '' : '<a class="button button-small" href="' . esc_url($link) . '">Start</a>') . '</li>';
        }
        echo '</ol></div>';
    }

    /* ---- ajax ---- */

    private static function guard(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden', 403);
        }
        check_ajax_referer('sgap_setup', 'nonce');
    }

    public static function ajax_save(): void {
        self::guard();
        $settings = isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : [];
        $state = self::state();
        if (isset($_POST['feeds_done'])) {
            $state['feeds_done'] = array_values(array_intersect(SGAP_Publer::CHANNELS, array_map('sanitize_key', (array) wp_unslash($_POST['feeds_done']))));
        }
        if (!empty($_POST['finish'])) {
            $state['finished'] = true;
        }
        update_option(self::STATE, $state, false);
        // Empty secret fields mean "keep what is saved".
        foreach (SGAP_Settings::SECRET_KEYS as $secret) {
            if (array_key_exists($secret, $settings) && trim((string) $settings[$secret]) === '') {
                unset($settings[$secret]);
            }
        }
        $result = $settings ? SGAP_AdminTools::update_settings(['settings' => $settings]) : ['changed' => []];
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        delete_transient('sgap_dashboard_stats');
        $done = 0;
        foreach (self::checklist() as [$ok]) {
            $done += $ok ? 1 : 0;
        }
        wp_send_json_success(['changed' => $result['changed'], 'done' => $done]);
    }

    public static function ajax_test(): void {
        self::guard();
        $r = SGAP_KeyCheck::run();
        wp_send_json_success(['ai' => $r['ai'], 'publer' => $r['publer'], 'printful' => $r['printful']]);
    }

    /* ---- fields ---- */

    public static function switch_field(string $name, bool $on, string $label = ''): string {
        return '<label class="sgap-switch"><input type="hidden" name="' . esc_attr($name) . '" value="no"><input type="checkbox" name="' . esc_attr($name) . '" value="yes"' . checked($on, true, false) . '>'
            . '<span class="sgap-slider" aria-hidden="true"></span>' . ($label !== '' ? '<span class="sgap-switch-label">' . esc_html($label) . '</span>' : '') . '</label>';
    }

    public static function channels_field(string $name): string {
        $current = SGAP_Publer::channels();
        $html = '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr(implode(',', $current)) . '" class="sgap-channels-value"><div class="sgap-channel-grid">';
        foreach (self::CHANNEL_LABELS as $key => $label) {
            $html .= '<label class="sgap-channel-card' . (in_array($key, $current, true) ? ' on' : '') . '"><input type="checkbox" value="' . esc_attr($key) . '"' . checked(in_array($key, $current, true), true, false) . '>'
                . '<span class="dashicons dashicons-' . esc_attr(SGAP_UI::ICONS[$key] ?? 'share') . '"></span><span>' . esc_html($label) . '</span>'
                . (in_array($key, SGAP_Publer::NEEDS_PHOTO, true) ? '<small>needs a photo</small>' : '') . '</label>';
        }
        return $html . '</div>';
    }

    public static function hour_field(string $name, int $value): string {
        $html = '<select name="' . esc_attr($name) . '">';
        for ($h = 0; $h < 24; $h++) {
            $html .= '<option value="' . $h . '"' . selected($value, $h, false) . '>' . sprintf('%02d:00', $h) . '</option>';
        }
        return $html . '</select>';
    }

    /**
     * The model dropdown: only what the provider lists right now can be picked, so a retired or
     * guessed model name can no longer be saved. Without a list the field stays free text, so an
     * unreachable provider never blocks the rest of the form.
     */
    public static function model_field(string $name): string {
        $id = 'sgap_ai_model';
        $current = trim((string) SGAP_Settings::get('ai_model'));
        $default = SGAP_AI::default_model();
        $models = SGAP_AI::catalog();
        if ($models === []) {
            return '<input type="text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($current)
                . '" class="sgap-text" spellcheck="false" placeholder="' . esc_attr($default !== '' ? $default : 'model id') . '">'
                . '<p class="sgap-hint">Could not read the model list from ' . esc_html(SGAP_AI::provider_name())
                . ' right now, so the name is free text. Leave it empty for the default'
                . ($default !== '' ? ' (' . esc_html($default) . ')' : '') . '.</p>';
        }
        $html = '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" class="sgap-model">'
            . '<option value=""' . selected($current, '', false) . '>'
            . esc_html($default !== '' ? 'Provider default: ' . $default : 'Provider default') . '</option>';
        if ($current !== '' && !in_array($current, $models, true)) {
            // Never hide what is saved: the owner has to see that it is gone.
            $html .= '<option value="' . esc_attr($current) . '" selected>' . esc_html($current) . ' (not offered any more)</option>';
        }
        foreach (self::group_models($models) as $vendor => $ids) {
            $html .= '<optgroup label="' . esc_attr($vendor) . '">';
            foreach ($ids as $model) {
                $html .= '<option value="' . esc_attr($model) . '"' . selected($current, $model, false) . '>' . esc_html($model) . '</option>';
            }
            $html .= '</optgroup>';
        }
        return $html . '</select><p class="sgap-hint">' . count($models) . ' model(s) that ' . esc_html(SGAP_AI::provider_name())
            . ' offers right now. The list is refreshed every 12 hours, so a retired model cannot be picked, and saving checks it again.</p>';
    }

    /** Model ids by their vendor prefix, so hundreds of ids stay navigable in one dropdown. */
    public static function group_models(array $models): array {
        $groups = [];
        foreach ($models as $model) {
            $vendor = strpos($model, '/') !== false ? (string) strstr($model, '/', true) : 'other';
            $groups[$vendor][] = $model;
        }
        ksort($groups);
        return $groups;
    }

    /** One settings field, named for options.php (sgap_<key>) or for the wizard (settings[<key>]). */
    public static function field(string $key, bool $wizard = false): string {
        $name = $wizard ? "settings[{$key}]" : 'sgap_' . $key;
        $id = 'sgap_' . $key;
        if (in_array($key, SGAP_Settings::BOOL_KEYS, true)) {
            return self::switch_field($name, SGAP_Settings::enabled($key));
        }
        if ($key === 'channels') {
            return self::channels_field($name);
        }
        if (in_array($key, SGAP_Settings::HOUR_KEYS, true)) {
            return self::hour_field($name, (int) SGAP_Settings::get($key));
        }
        if (isset(SGAP_Settings::CHOICE_KEYS[$key])) {
            $current = (string) SGAP_Settings::get($key);
            $html = '<div class="sgap-choice-row">';
            foreach (SGAP_Settings::CHOICE_KEYS[$key] as $value => $label) {
                $html .= '<label class="sgap-choice' . ($current === (string) $value ? ' on' : '') . '"><input type="radio" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"' . checked($current, (string) $value, false) . '><span>' . esc_html($label) . '</span></label>';
            }
            return $html . '</div>';
        }
        if (in_array($key, SGAP_Settings::SECRET_KEYS, true)) {
            if ($const = SGAP_Settings::constant_name($key)) {
                return '<em>Set in wp-config.php (<code>' . esc_html($const) . '</code>)</em>';
            }
            $saved = get_option('sgap_' . $key, '') !== '';
            $html = '<div class="sgap-secret"><input type="password" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="" autocomplete="new-password" placeholder="' . esc_attr($saved ? '•••••••• saved – leave empty to keep' : 'Paste the key') . '">'
                . ($saved ? '<span class="sgap-pill ok">Saved</span>' : '') . '</div>';
            if ($saved && !$wizard) {
                $html .= '<label class="sgap-clear"><input type="checkbox" name="sgap_clear[' . esc_attr($key) . ']" value="1"> Remove saved key</label>';
            }
            return $html;
        }
        if ($key === 'ai_model') {
            return self::model_field($name);
        }
        if (in_array($key, SGAP_Settings::TEXTAREA_KEYS, true)) {
            return '<textarea id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" rows="4" class="sgap-text" spellcheck="false">' . esc_textarea((string) SGAP_Settings::get($key)) . '</textarea>';
        }
        $number = in_array($key, SGAP_Settings::INT_KEYS, true);
        return '<input type="' . ($number ? 'number' : 'text') . '" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr((string) SGAP_Settings::get($key)) . '"'
            . ($number ? ' min="0" class="sgap-num"' : ' class="sgap-text"') . '>';
    }

    private static function row(string $key, bool $wizard = false): string {
        $label = self::LABELS[$key] ?? ucfirst(str_replace('_', ' ', $key));
        $help = SGAP_Settings::HELP[$key] ?? '';
        return '<div class="sgap-field"><div class="sgap-field-label"><label for="sgap_' . esc_attr($key) . '">' . esc_html($label) . '</label>'
            . ($help !== '' ? '<p>' . esc_html($help) . '</p>' : '') . '</div><div class="sgap-field-input">' . self::field($key, $wizard) . '</div></div>';
    }

    /* ---- Settings page ---- */

    public static function settings_page(): void {
        SGAP_Admin::open('Settings', 'Everything in one place. New here? Use the setup guide instead.');
        if (isset($_GET['settings-updated'])) {
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        }
        echo '<form method="post" action="options.php" class="sgap-settings">';
        settings_fields('sgap_settings');
        echo '<div class="sgap-tabs" role="tablist">';
        $first = true;
        foreach (self::TABS as $id => [$label, $icon]) {
            echo '<button type="button" role="tab" class="sgap-tab' . ($first ? ' on' : '') . '" data-tab="' . esc_attr($id) . '"><span class="dashicons dashicons-' . esc_attr($icon) . '"></span>' . esc_html($label) . '</button>';
            $first = false;
        }
        echo '<a class="sgap-tab sgap-tab-link" href="' . esc_url(admin_url('admin.php?page=sgap-setup')) . '"><span class="dashicons dashicons-welcome-learn-more"></span>Setup guide</a></div>';
        $first = true;
        foreach (self::TABS as $id => $tab) {
            $keys = (array) $tab[2];
            echo '<div class="sgap-card sgap-panel' . ($id === 'keys' ? ' sgap-panel--keys' : '') . '" data-panel="' . esc_attr($id) . '"' . ($first ? '' : ' hidden') . '>';
            if ($id === 'keys') {
                SGAP_Keys::panel();
            } else {
                // Every tab opens with the question it answers, so the fields below have a place.
                echo '<div class="sgap-panel-head"><h2><span class="dashicons dashicons-' . esc_attr($tab[1]) . '"></span>' . esc_html($tab[0]) . '</h2>'
                    . (isset(self::TAB_HINTS[$id]) ? '<p class="sgap-section-hint">' . esc_html(self::TAB_HINTS[$id]) . '</p>' : '') . '</div>';
                // A secret belongs on the keys tab and nowhere else, even if it is listed here by mistake.
                foreach (array_diff($keys, SGAP_Settings::SECRET_KEYS) as $key) {
                    echo self::row($key);
                }
            }
            echo '</div>';
            $first = false;
        }
        // Registered settings not on a tab keep their values (options.php only saves fields it receives).
        echo '<div class="sgap-savebar"><span class="sgap-dirty" hidden>Unsaved changes</span><span class="description">Every tab is saved at once.</span>';
        submit_button('Save settings', 'primary', 'submit', false);
        echo '</div></form>';
        // Markeringen af ugemte aendringer ligger i assets/pages/setup.js.
        SGAP_Assets::page_script('setup', 'SGAP_SETUP', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('sgap_setup')]);
        SGAP_Admin::close();
    }

    /* ---- Wizard ---- */

    public static function wizard(): void {
        SGAP_Admin::open('Setup guide', 'Five short steps. Everything can be changed later under Settings.');
        $state = self::state();
        $keys = get_option(SGAP_KeyCheck::RESULT);
        $steps = [
            'ai' => ['Connect the AI', 'superhero-alt'],
            'channels' => ['Channels', 'share'],
            'publer' => ['Publer', 'megaphone'],
            'schedule' => ['Schedule', 'clock'],
            'extras' => ['Extras', 'admin-plugins'],
            'done' => ['Done', 'yes-alt']
        ];
        echo '<div class="sgap-wizard"><ol class="sgap-rail">';
        $n = 1;
        foreach ($steps as $id => [$label, $icon]) {
            echo '<li data-step="' . esc_attr($id) . '"><span class="sgap-num">' . $n++ . '</span><span>' . esc_html($label) . '</span></li>';
        }
        echo '</ol><div class="sgap-wizard-body">';

        // 1 AI
        $provider = SGAP_AI::provider();
        echo '<form class="sgap-card sgap-step" data-step="ai"><h2>Which AI should write for you?</h2><p class="sgap-sub">The AI writes your social posts, articles and answers in the chat.</p><div class="sgap-choice-row sgap-big">';
        foreach (['aimlapi' => ['AIMLAPI', 'Recommended. Claude and 300+ models plus images with one key. Pay as you go.'], 'anthropic' => ['Anthropic (Claude)', 'Directly from Anthropic. Text only – images need an AIMLAPI key.'], 'openrouter' => ['OpenRouter', 'One key in front of hundreds of models from many providers. Pick a model after saving.'], 'openai_compatible' => ['Other', 'OpenAI or any OpenAI-compatible API with your own address.']] as $value => [$title, $text]) {
            echo '<label class="sgap-choice' . ($provider === $value ? ' on' : '') . '"><input type="radio" name="settings[ai_provider]" value="' . esc_attr($value) . '"' . checked($provider, $value, false) . '><span><strong>' . esc_html($title) . '</strong><small>' . esc_html($text) . '</small></span></label>';
        }
        $ai_saved = trim((string) SGAP_Settings::get('ai_api_key', '')) !== '' || SGAP_Settings::constant_name('ai_api_key');
        echo '</div>' . ($ai_saved
                ? '<div class="sgap-connected">' . SGAP_UI::pill('Key saved', 'ok') . ' <span>Change it under <a href="'
                    . esc_url(admin_url('admin.php?page=sgap-settings#keys')) . '">Settings → Keys</a> — that is the only place keys are pasted.</span></div>'
                : self::row('ai_api_key', true))
            . '<details class="sgap-more"><summary>Model and address (optional)</summary>' . self::row('ai_model', true) . self::row('ai_base_url', true) . '</details>'
            . '<div class="sgap-test-result">' . (is_array($keys) && isset($keys['ai']) ? SGAP_UI::pill('AI ' . ($keys['ai']['ok'] ? '✓' : '✗'), $keys['ai']['ok'] ? 'ok' : 'bad') . ' <span>' . esc_html($keys['ai']['message']) . '</span>' : '') . '</div>'
            . '<div class="sgap-step-nav"><span></span><button class="button button-primary" data-next>Save, test &amp; continue</button></div></form>';

        // 2 Channels
        echo '<form class="sgap-card sgap-step" data-step="channels" hidden><h2>Where should your posts go?</h2><p class="sgap-sub">Pick the networks you use. Instagram and Pinterest need a photo on each post – the AI can make one.</p>'
            . self::channels_field('settings[channels]')
            . '<div class="sgap-step-nav"><button type="button" class="button" data-back>Back</button><button class="button button-primary" data-next>Continue</button></div></form>';

        // 3 Publer
        $mode = SGAP_RSS::enabled() ? 'rss' : 'api';
        echo '<form class="sgap-card sgap-step" data-step="publer" hidden><h2>How do posts reach Publer?</h2><div class="sgap-choice-row sgap-big">'
            . '<label class="sgap-choice' . ($mode === 'rss' ? ' on' : '') . '"><input type="radio" name="settings[publish_mode]" value="rss"' . checked($mode, 'rss', false) . '><span><strong>RSS feeds</strong><small>Publer Professional. One feed per channel that Publer auto-posts from.</small></span></label>'
            . '<label class="sgap-choice' . ($mode === 'api' ? ' on' : '') . '"><input type="radio" name="settings[publish_mode]" value="api"' . checked($mode, 'api', false) . '><span><strong>Publer API</strong><small>Publer Business. Posts are sent straight to Publer.</small></span></label></div>'
            . '<div class="sgap-mode" data-mode="rss"><ol class="sgap-howto"><li>Open Publer → <em>Explore → RSS Feeds → Add feed</em>.</li><li>Paste a feed below, open its <em>Settings</em>, turn on <strong>Auto-post</strong> and pick the account.</li><li>Tick it here when done.</li></ol><div class="sgap-feedlist">';
        foreach (SGAP_Publer::CHANNELS as $channel) {
            $url = SGAP_RSS::url($channel);
            echo '<div class="sgap-feed" data-channel="' . esc_attr($channel) . '">' . SGAP_UI::channel($channel) . '<code>' . esc_html($url) . '</code>'
                . '<button type="button" class="button button-small sgap-copy" data-url="' . esc_attr($url) . '"><span class="dashicons dashicons-admin-page"></span>Copy</button>'
                . '<label class="sgap-done-box"><input type="checkbox" name="feeds_done[]" value="' . esc_attr($channel) . '"' . checked(in_array($channel, (array) $state['feeds_done'], true), true, false) . '> Added</label></div>';
        }
        echo '</div><p><a class="button" href="https://app.publer.com/" target="_blank" rel="noopener"><span class="dashicons dashicons-external"></span>Open Publer</a></p></div>'
            . '<div class="sgap-mode" data-mode="api" hidden>' . self::row('publer_api_key', true) . self::row('publer_workspace_id', true) . self::row('publer_pinterest_board', true) . '</div>'
            . '<div class="sgap-step-nav"><button type="button" class="button" data-back>Back</button><button class="button button-primary" data-next>Continue</button></div></form>';

        // 4 Schedule
        echo '<form class="sgap-card sgap-step" data-step="schedule" hidden><h2>When and how much?</h2>'
            . self::row('autopilot_enabled', true) . self::row('full_auto_enabled', true) . self::row('posts_per_day', true) . self::row('daily_cap', true)
            . '<div class="sgap-field"><div class="sgap-field-label"><label>Quiet hours</label><p>Nothing is released in this window (site time).</p></div><div class="sgap-field-input sgap-inline">'
            . self::hour_field('settings[quiet_start]', (int) SGAP_Settings::get('quiet_start', 23)) . '<span>to</span>' . self::hour_field('settings[quiet_end]', (int) SGAP_Settings::get('quiet_end', 7)) . '</div></div>'
            . '<div class="sgap-step-nav"><button type="button" class="button" data-back>Back</button><button class="button button-primary" data-next>Continue</button></div></form>';

        // 5 Extras
        echo '<form class="sgap-card sgap-step" data-step="extras" hidden><h2>Extras for articles and images</h2><p class="sgap-sub">Optional. Make the Content Studio smarter.</p>'
            . self::row('serpapi_key', true) . self::row('content_language', true) . self::row('image_model', true) . self::row('image_api_key', true)
            . '<div class="sgap-step-nav"><button type="button" class="button" data-back>Back</button><button class="button button-primary" data-next>Finish</button></div></form>';

        // 6 Done
        echo '<div class="sgap-card sgap-step" data-step="done" hidden><h2>🎉 You are set up</h2><p class="sgap-sub">Here is what is left – the dashboard keeps this list until everything is ticked.</p><div class="sgap-done-list"></div>'
            . '<div class="sgap-actions"><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=steamgears-autopilot')) . '"><span class="dashicons dashicons-dashboard"></span>Go to the dashboard</a>'
            . '<a class="button" href="' . esc_url(admin_url('admin.php?page=sgap-studio')) . '"><span class="dashicons dashicons-edit-page"></span>Write an article</a>'
            . '<a class="button" href="' . esc_url(admin_url('admin.php?page=sgap-chat')) . '"><span class="dashicons dashicons-format-chat"></span>Ask the AI</a></div></div>';
        echo '</div></div>';

        $cfg = ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('sgap_setup')];
        SGAP_Assets::page_script('setup', 'SGAP_SETUP', ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('sgap_setup')]);
        // The "done" step lists the checklist, rendered server-side.
        ob_start();
        self::checklist_card();
        $card = ob_get_clean();
        // Skabelonen kopieres ind i listen af assets/pages/setup.js.
        echo '<template id="sgap-done-tpl">' . ($card !== '' ? $card : '<p>Everything is done. Enjoy the autopilot!</p>') . '</template>';
        SGAP_Admin::close();
    }
}
