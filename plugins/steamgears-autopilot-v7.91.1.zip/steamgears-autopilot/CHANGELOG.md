# Patch notes — Steamgears Autopilot

Nyeste version øverst. Hver note siger hvad der blev **tilføjet, ændret eller rettet**, hvordan det er
målt, og hvilket versionsnummer den hører til. Versionsnummeret i den øverste overskrift skal matche
`SGAP_VERSION`, plugin-headerens `Version:` og navnet på zip'en i `plugins/` — det tjekkes af
`python3 tools/patch_notes.py --check`.

Noterne er skrevet ud fra commit-historikken og de dokumenter der hører til hver version. Versioner før
7.65.0 er ikke backfillet; deres historik står i git og i README's afsnit pr. funktion.

<!-- patch-notes: baseline 7.65.0 -->

## 7.91.1 — 2026-11-19

**Rettet: siden *Gelato print orders* gav en PHP-fejl.**

### Rettet
- Siden brugte `SGAP_Admin::card_open()`, som ikke findes; kortene hedder `SGAP_UI::card_open()`/`card_close()`. Fundet live lige efter opdateringen til 7.91.0. Selve videresendelsen af ordrer var ikke berørt.

### Målt
- 1.594 smoke-checks bestod. Tre nye viser siden og tjekker de 19 plakater, markeringen af manglende trykfiler og trykfilens adresse; det første fejler på 7.91.0.

## 7.91.0 — 2026-11-19

**Tilføjet: Gelato-tryk af de 19 plakater direkte fra betalte ordrer.**

### Tilføjet
- Nyt modul *Gelato print orders* (`includes/gelato.php`, menu *Shop*). Betalte ordrer med variant-SKU `SG-DA|SG-CC|SG-AC-NN-3040|5070` sendes til Gelatos ordre-API (`POST /v4/orders`, 200 g mat, `flat_product_pf_300x400-mm…`/`500x700-mm…`) med trykfilen fra `uploads/<sggf_print_dir>/`. Andre varer røres ikke, og ingen produkter skal kobles i Gelatos egen app.
- Tilstand *Off* (standard), *Draft* (kladdeordre i Gelato, godkendes dér) og *Live*. Én Gelato-ordre pr. WooCommerce-ordre (option-lås + `_sggf_gelato_order_id`). Timeout, 429 og 5xx prøves igen efter 15 og 30 minutter; 4xx bliver en ordrenote. Ordrehandlingen *Send posters to Gelato* sender manuelt.
- Flyttet ind fra det selvstændige plugin `sg-gelato-forward` 1.0.0. Option- og meta-nøglerne er de samme (`sggf_*`), så nøgle, tilstand og trykfilmappe følger med. Mens det gamle plugin er aktivt, sender modulet intet og siger det på siden.

### Rettet
- En manglende indstilling gav tom tilstand i stedet for *Off* (også rettet i kildekoden til det selvstændige plugin).

### Målt
- 1.591 smoke-checks bestod, heraf 10 nye for Gelato (SKU-genkendelse, filnavne, produkter, genforsøg, standardtilstand, ordrehandling, menu).
- Samme JSON som modulet bygger, blev sendt som kladde til Gelato 19/11: HTTP 200, Gelato hentede begge trykfiler (samme bytestørrelse), og kladden er slettet igen.
- En rigtig betalt ordre gennem WooCommerce er ikke ende-til-ende-testet.

## 7.90.0 — 2026-11-18

**Ændret: enklere navigation og tydeligere status; rettet fejl i kø og administration.**

### Ændret
- Genveje forbinder overblik, kladder, kø, resultater og indstillinger. Menuer, ikoner og layout er ryddet op, og smalle skærme er understøttet.
- RSS-opslag vises som frigivet til feedet, ikke som bekræftet offentliggjort på en social platform.
- Indstillingsfaner kan bruges med tastatur og viser korrekt valgt tilstand for hjælpeteknologi.

### Rettet
- To samtidige publiceringsprocesser kan ikke længere begge overtage samme køpost.
- En mislykket plugininstallation kan rapportere fejlen uden en PHP-fatal, når WordPress returnerer en streng.
- Overblik og indstillinger kaster ikke længere JavaScript-fejl, når valgfrie elementer mangler.

### Målt
- 1.581 smoke-checks og integrationstest med WordPress 7.1.5 og MariaDB bestod.
- 19 administrationssider åbnet i Chromium ved 1440 og 320 pixels. Faner og opsætningsguide er prøvet interaktivt.
- Eksterne publicerings- og AI-tjenester er ikke ende-til-ende-testet i denne version.

## 7.89.0 — 2026-11-17

**Tilføjet: dashboardets advarsler viser nu det næste konkrete skridt.**

### Tilføjet
- En fejlet AI-nøgletest linker til *Settings → Keys*, og self-check-problemer linker til *Fejlsøgning*.
- Ventende kladder linker til *Drafts to approve*. Alle fire publiceringsblokeringer (autopilot slået fra, quiet hours, dagligt loft og blackout) linker til *Setup → Schedule*.
- Handlingslinks vises kun ved den relevante advarsel; *All clear* forbliver uden ekstra knapper. Handlingsrækken kan ombrydes på smalle skærme.

### Målt
- `plugins/tests/smoke.php`: alle checks grønne, inkl. otte nye destinations-/tilstandschecks for P16.
- PHP-lint, `tools/patch_notes.py --check` og `tools/fejlscan.py` bestod. Den samlede natlige suite havde én urelateret fejl i `guide-copy` (tre døde `/go/`-links).

## 7.88.2 — 2026-11-16

**Rettet: `call-ability` kunne ikke køre abilities uden input-skema (fx `cirla-status`).**

### Rettet
- `SGAP_MCP_Tools::call_ability()` sendte altid et tomt array videre. WordPress afviser ethvert input, der ikke
  er `null`, til en ability uden input-skema (`ability_missing_input_schema`), så `cirla-status` og lignende
  svarede med en fejl gennem escape-hatchen. Uden argumenter sendes nu `null`.

### Målt
- Fejlen genskabt live over MCP 16/11 07.14 (7.88.1). To nye smoke-checks med en ability der opfører sig som
  WordPress: kald uden input kører, rigtigt input går stadig igennem. 1 566 PASS / 0 FAIL.
- Samme dag live: Cirla tændt igen (stod slukket), `cirla-social-suggestions` på post 1361 gav tre rigtige
  AI-forslag via OpenRouter (intet gemt, intet i kø).

## 7.88.1 — 2026-11-16

**Rettet: kanal-sundheden (`channel-health`) gav en fatal fejl på det levende site.**

### Rettet
- `SGAP_Channel_Health::analytics()` brugte SQL-aliasset `rows`, som er et reserveret ord i MySQL 8.
  Forespørgslen fejlede, og wpdb kastede `mysqli_num_fields(): Argument #1 ($result) must be of type
  mysqli_result, false given`. Både abilityen `channel-health` og `/sgap/v1/channel-health` var derfor
  døde. Aliasset hedder nu `rows_count`, som i Facebook-, Instagram- og engagement-modulerne.

### Målt
- Fejlen genskabt live over MCP 16/11 kl. 06.57 (7.88.0).
- Ny smoke-check afviser reserverede ord som SQL-alias i forespørgslen; den fejler mod den gamle kode og
  består mod den nye. 1 564 PASS / 0 FAIL. Testdataen brugte selv `rows`, og derfor fangede mock'en ikke fejlen.
- Ikke målt: den rettede forespørgsel mod sitets rigtige database (kræver installation af 7.88.1).

## 7.88.0 — 2026-11-15

**Fjernet: Printful. Gelato er printvejen, og pluginet beder ikke længere om et Printful-token.**

### Fjernet
- Printful-kortet under *Settings → Keys*, Printful-nøgletesten (`SGAP_KeyCheck::check_printful()`) og
  felterne `printful_api_key` og `printful_store_id` (indstillinger, etiketter, hjælpetekster, *Shop & feeds*).
- Kostpris-importen fra Printfuls sync-varianter: abilityen `woo-cost-import`, `printful_cost()`,
  sync-produktopslaget, indekset og prischachen. Kataloget har nu 35 værktøjer (før 36).
- Ved opgradering slettes de gemte Printful-indstillinger og prischachen fra sitet.

### Ændret
- Kostprisen kommer kun fra produktets eget felt `_sgap_cost`, fx Gelato-prisen. En note i
  `_sgap_cost_source` vises ved tallet. Uden kostpris afvises et forslag stadig, og fejlteksten nævner feltet
  og Gelato.
- Nichebutikken skriver produktion, fragt og størrelsesskema med Gelato, og første ejertrin er
  "Connect Gelato (wp-admin → Gelato) and enter each product's cost".
- *Test connections* tester AI og Publer.

### Målt
- Live 15/11 svarede nøgletesten "The token works, but it sees no store" for et Printful-token, som ingen
  skal bruge. Ejeren 15/11: "Printful er ude ligesom Printify, vi kører kun Gelato".
- `plugins/tests/smoke.php`: 1 563 PASS / 0 FAIL. De 27 Printful-import- og nøgletest-checks er erstattet af
  8 checks for, at Printful er væk, at kosten kun læses fra feltet, og at opgraderingen sletter indstillingerne.
  `tools/deploy/niche_preflight.py --check`: 4 nicher, 0 fejl efter `--build`.

### Ikke målt
- Gelato-forbindelsen selv. Den sker i det officielle Gelato-plugin og er ikke gennemført (S4.7).

## 7.87.1 — 2026-11-15

**Ændret: skribenten får listen over forbudte ord, så kvalitetsporten ikke skal stoppe opslaget bagefter.**

### Ændret
- `SGAP_AI::prompt()` nævner ordene fra *Settings → General → Banned words* (højst 40) med en klar instruks
  om aldrig at bruge dem. Uden forbudte ord kommer linjen ikke med.

### Målt
- Live 14/11: et Pinterest-opslag fik 8/10 af redaktøren, men blev holdt tilbage af kvalitetsporten, fordi
  det indeholdt "price" fra listen. Kladden ventede derfor på et menneske.
- `plugins/tests/smoke.php`: 1 586 PASS / 0 FAIL (2 nye checks).

## 7.87.0 — 2026-11-15

**Ændret: færre hashtags, en egen åbning pr. kanal og den hurtigste gratis model først hos AI-redaktøren.**

### Ændret
- Instagram beder om 3-5 konkrete hashtags (før 8-15) og Pinterest om 2-4 (før 3-6), og Pinterest-teksten
  bruger hovedsøgeordet én gang i stedet for at være "keyword-rich".
- Prompten kræver en egen åbningslinje og vinkel pr. kanal.
- `SGAP_AI::parse_posts()` håndhæver loftet (`TAG_CAP`), også når en model ignorerer reglen. Dubletter
  fjernes før loftet, og Telegram og Google får ingen hashtags.
- AI-redaktøren spørger Nemotron Super før Nemotron Ultra. Ultra er stadig på listen.

### Målt
- Live 14/11: genbedømmelsen (7.86.0) afviste 3 af 6 opslag, alle for hashtag-stuffing (15 tags på Instagram)
  og/eller samme åbning på alle kanaler. Nemotron Ultra svarede ikke inden for 52 s, mens Super svarede på
  ca. 20 s.
- `plugins/tests/smoke.php`: 1 584 PASS / 0 FAIL (3 nye `7.87`-checks).

### Ikke målt
- Om de nye regler giver højere redaktørscorer på sitet. Det viser de næste kørsler.

## 7.86.0 — 2026-11-14

**Tilføjet: opslag, som AI-redaktøren ikke nåede at bedømme, bliver spurgt igen hver time i stedet for at vente på et menneske.**

### Tilføjet
- `SGAP_Editor::rereview()` kører på det timelige `sgap_rescue`-job. Den læser kun kladder med status `pending`
  og noten *Editor: not checked* eller *Editor: no score* fra de sidste 3 dage (`RETRY_DAYS`), højst 5 sider
  pr. time (`RETRY_PAGES`, ét redaktørkald pr. side), så en ophobning ikke oversvømmer de gratis modeller.
- 7/10 eller mere køes i Full auto (uden Full auto forbliver det en kladde), under 7 afvises med grunden, og
  ny tavshed lader kladden ligge til næste time. Noten får *(asked again)* på.
- Rækken låses med `UPDATE … AND status = 'pending'`, så en kladde, som et menneske har redigeret eller brugt
  i mellemtiden, aldrig bliver køet af genbedømmelsen.

### Ændret
- Selvtjekket siger nu, at tilbageholdte opslag spørges igen hver time i 3 dage, og efter en genbedømmelse
  hvor mange der stadig mangler svar.

### Målt
- Live 14/11 kl. 01:21: 6 opslag fra kørslen 13/11 19:47 ventede, fordi ingen gratis model svarede. Et nyt
  redaktørkald fra sitet svarede på 9,3 s (`nemotron-3.5-super-vl:free`) og var strengt: 7/10 med en note
  om en påstand, der ikke stod på siden.
- `plugins/tests/smoke.php`: 1 581 PASS / 0 FAIL (11 nye `7.86`-checks: krog, SQL-filter, ét kald pr. side,
  kø/afvisning, låsning, tavshed, uden Full auto, loft på 5 sider, uden redaktør og selvtjekkets tekst).

### Ikke målt
- En rigtig time-kørsel på sitet efter installation.

## 7.85.1 — 2026-11-13

**Rettet: to fejlbeskeder pegede på den gamle fane — og integrationstesten er nu faktisk kørt mod et rigtigt WordPress.**

### Rettet
- `SGAP_AI::json_call()` og `SGAP_Generator::generate()` siger nu *Settings → AI* (ikke *AI & images*), når der
  ikke er valgt en model.
- `plugins/tests/integration.php` indeholdt fra 7.85.0-arbejdet både den nye OpenRouter-blok og en kopi af den
  gamle keycheck-blok, og evergreen-afsnittet brugte stadig Anthropic-formatet. Dubletten er fjernet, og alle
  mocks matcher nu OpenRouters `/models` med query-parametre samt `/chat/completions` i OpenAI-format.
- `plugins/tests/automation.php` slår AI-redaktøren fra i dette forløb (den har sin egen suite) og rydder
  `sgap_new_content` før testindlægget, så kun det publicerede indlæg promoveres — 2 kladder, ikke 4.

### Målt
- `plugins/tests/integration.sh` mod WordPress 7.1.4, MariaDB 10.11 og PHP 8.3: **254 PASS / 0 FAIL** —
  in-process 155, admin-tools 45, automation 27, HTTP 18 og 9 uninstall-checks; ingen plugin-notitser i
  `debug.log`.
- Smoke: 1 570 PASS / 0 FAIL.
- Opsætningen uden root (apt-get download + dpkg -x, portabel MariaDB, wp-cli-phar) står i
  `docs/library/integrationstest-wordpress-2026-11-13.md`.

## 7.85.0 — 2026-11-13

**OpenRouter er nu den eneste AI-udbyder, og AI-billedgenerering er væk.**

### Fjernet
- AIMLAPI, Anthropic og *Other OpenAI-compatible* som valg. `SGAP_AI::provider()` svarer altid
  `openrouter`, `base_url()` er den faste `https://openrouter.ai/api/v1`, og en gammel gemt
  `ai_provider`-værdi læses ikke længere.
- Reserve-udbyderen (egen nøgle, eget model-felt, failover) og gratis-model-forsøget ved kreditfejl.
  En fejl fra OpenRouter rapporteres med providerens egne ord i stedet for at blive prøvet igen på en
  anden model.
- Al AI-billedgenerering: `SGAP_Images`, `image_api_key`, `image_model`, `openrouter_image_model`,
  `auto_images`, `generate-image`-abilityen, AJAX-billedopgaven og billedfelterne i guiden, opsætningen
  og Content Studio. `includes/openrouter.php` (flytte-knappen) er slettet.
- Standardmodel. Der findes ingen gættet slug: et tomt modelvalg er tomt, og nøgletesten beder om et valg.

### Ændret
- Content Studio skriver tekst. Instagram og Pinterest bruger sidens eksisterende featured image
  (`get_the_post_thumbnail_url()`); mangler den, fejler opslaget med en besked der navngiver rettelsen.
  Uploadede medier og featured images røres ikke.
- Fanen *Settings → AI & images* heder nu *Settings → AI*, og alle henvisninger peger på *Settings → AI*
  og *Settings → Keys*. Nøglesiden har ét OpenRouter-kort; guiden har ét AI-trin.
- Selvtjek og RSS-forhåndstjek nævner ikke længere AI-fotos eller en reserve-udbyder.
- Modelfeltet er stadig en dropdown over OpenRouters live `/models`, med en synlig markering af et navn
  der ikke længere udbydes, og ingen *Provider default*.

### Målt
- `plugins/tests/smoke.php`: 1 570 PASS, 0 FAIL (AI- og billedafsnittene er skrevet om til
  OpenRouter-only, inkl. checks for at reserve-API'et, `SGAP_Images` og `generate-image` er væk).
- `plugins/tests/cc-login.php`, `keys.php`, `automation.php`, `integration.php` og `admin-tools.php` er
  opdateret til samme virkelighed (OpenRouter-mocks, featured image i stedet for genereret foto,
  42 abilities i stedet for 43).

### Ikke målt
- Intet kald er gået til den rigtige OpenRouter, og intet WordPress er kørt her: der findes ingen nøgle
  i sandkassen, og integrationstesten kræver MySQL + wp-cli.

## 7.84.1 — 2026-11-12

**Rettet: et Pinterest-token til at oprette pins skal have begge board-scopes.**

### Rettet
- Målt live mod Pinterest: `POST /v5/pins` med *Pinterest for WooCommerce*-tokenet, som har `pins:write`,
  svarer 401 `Missing: ['boards:read', 'boards:write']`. Tokenet fra WooCommerce kan derfor ikke poste.
- Indstillingshjælpen og fejlbeskeden siger nu `pins:write, boards:read og boards:write`.
- `tools/pinterest_connect.py` beder om `boards:read,boards:write,pins:read,pins:write,user_accounts:read`.
- Guiden `docs/library/publer-udfasning-2026-11-12.md` er rettet efter målingen:
  - App ID mangler på sitet.
  - Det gamle eget token er udløbet.
  - Der ligger et kandidat-board i `sg_pinterest_board`.
  - TikTok-nøglerne fra WooCommerce (`tt4b_*`) er til annoncer, ikke til at poste opslag.

## 7.84.0 — 2026-11-12

**Publer kan udfases kanal for kanal: pluginnet poster nu selv til Instagram og Pinterest, og direkte kanaler virker også i RSS-tilstand og uden Publer-nøgle.**

### Tilføjet
- `includes/direct.php` (`SGAP_Direct`) bestemmer, hvilke kanaler pluginnet poster selv, og bogfører
  udfaldet som Publer-vejen: backoff ved fejl, publiceret med platformens id ved succes.
  - `split()` viser, hvilke kanaler der er direkte, og hvilke der stadig går til Publer.
  - `publer_free()` er sand, når ingen tændt kanal længere behøver Publer.
- **Instagram** (`instagram_direct`): container → statustjek til `FINISHED` → `media_publish`. Kræver
  `instagram_business_content_publish` og en offentlig JPEG.
- **Pinterest** (`pinterest_direct` + `pinterest_board_id`): `POST /v5/pins` med board, titel, tekst,
  alt-tekst, billede og sporingslink. Kræver `pins:write` og `boards:read`. Preflightens board-tjek godtager
  den direkte board, så Publers board-indstilling ikke længere er nødvendig.
- Guide: `docs/library/publer-udfasning-2026-11-12.md` (+ PDF) med tokens hos Meta og Pinterest,
  rækkefølgen og hvornår Publer kan opsiges.
- 19 nye checks i `plugins/tests/direct.php` (1 613 → 1 632 PASS, 0 FAIL).

### Ændret
- RSS-tilstanden poster en direkte kanal selv i stedet for at lægge opslaget i feedet. Feed-sundheden
  viser `direct` for den.
- API-tilstanden kører uden Publer-nøgle, når mindst én kanal er direkte. Et opslag til en kanal, der
  hverken er direkte eller har Publer, fejler med en forklaring.
- De fire eksisterende direkte kanaler (Bluesky, Mastodon, Telegram, Facebook) går gennem samme
  `SGAP_Direct`. Adfærden er uændret.
- Instagram-modulets transport kan nu også sende POST.

### Bemærk
- Alle tre direkte kanaler er **slået fra som standard**. Uden ejerens tokens ændrer installationen intet.

## 7.83.2 — 2026-11-12

**Rettet: redaktørens svar blev skåret af, før det kom.**

### Rettet
- De gratis modeller ræsonnerer, før de svarer. Med `max_tokens` 1 200 gik alt til ræsonnementet
  (`finish_reason=length`, tomt svar, målt live). Redaktøren holdt derfor sikkert alle opslag
  tilbage. Loftet er nu 4 000, hvilket er gratis på `:free`-modeller.
- Målt live efter rettelsen med `nemotron-3-ultra:free` (ca. 10 s):
  - Rigtige opslag: Facebook 8/10 (godkendt), Instagram 5/10 (afvist for 15 hashtags og for mange
    emoji), Pinterest 9/10 (godkendt).
  - Et bevidst dårligt opslag med opdigtet »70% OFF«, »free worldwide shipping«, klichéer og
    gentagne hashtags: 1/10, med alle fire grunde.
- Smoke-checket kræver nu loftet (1 613 PASS, 0 FAIL).

## 7.83.1 — 2026-11-12

**Rettet: AI-redaktøren og den gratis reserve sendte for mange modeller til OpenRouter.**

### Rettet
- OpenRouter afviser mere end 3 modeller i `models`. Målt live med 7.83.0: »'models' array must have 3
  items or fewer«.
  - `SGAP_Editor::MODELS` er nu `nemotron-3-ultra:free`, `nemotron-3.5-super-vl:free` og
    `openrouter/free`.
  - Både `SGAP_Editor::models()` og `SGAP_AI::free_models()` skærer en filtreret liste ned til 3.
- Fejlen var sikker. Uden et svar holdt redaktøren alle opslag tilbage som `pending`, og intet kom i
  køen.
- 1 nyt smoke-check (1 612 → 1 613 PASS, 0 FAIL).

## 7.83.0 — 2026-11-12

**En AI-redaktør læser hvert socialt opslag, før det må komme i køen. Svage opslag afvises med grunden, og når ingen redaktør svarer, venter opslagene på dig, også i Full auto.**

### Tilføjet
- `includes/editor.php` (`SGAP_Editor`). Hver side får ét gratis kald til OpenRouter (kun `:free`-modeller
  og `openrouter/free`), der giver sidens opslag en score fra 0 til 10 ud fra selve siden.
  - Der trækkes hårdt for priser, rabatter, fragtløfter og påstande, der ikke står på siden, og for
    AI-klichéer, ens indledninger på tværs af kanaler, hashtag-fyld og forkert tone.
- `write_for()` bruger dommen:
  - **≥ 7:** kladden kan sættes i kø som før.
  - **< 7:** kladden gemmes som `rejected` med begrundelsen i *Checks*.
  - **Ingen svar eller ikke-læsbar JSON:** kladden bliver `pending` og sættes **ikke** i kø
    automatisk.
- Kørselsrapporten tæller `rejected` og `held`, og selvtjekket nævner dem.
- Redaktøren kører kun med en OpenRouter-nøgle (hoved- eller reservenøgle). Anthropic-opsætninger
  er uændrede.
  - Filtrene `sgap_editor_min_score` og `sgap_editor_models` ændrer grænse og modeller.
  - En tom modelliste slår redaktøren fra.
- 12 nye smoke-checks (1 600 → 1 612 PASS, 0 FAIL).

### Bemærk
- Billeder til artikler laves og kvalitetssikres nu af Command Center (v7.34.0) og kommer med
  artiklen som udvalgt billede. Pluginnets egne sociale opslag bruger sidens udvalgte billede som
  før.

## 7.82.0 — 2026-11-12

**Command Center fortæller nu autopiloten, hvilke sider der er tæt på toppen af Google, og for hvilket søgeord. De sider får sociale opslag først, og søgeordet bruges i opslaget.**

### Tilføjet
- `includes/priorities.php` (`SGAP_Priorities`) og ruten `POST/GET /sgap/v1/priorities` (kræver
  `manage_options`, som resten af API'et). Command Center sender op til 30 sider: `url`, `keyword`,
  `position` og `reason`.
  - Kun publicerede indlæg, sider og produkter gemmes. Ukendte sider, kladder og dubletter afvises
    med en grund i svaret.
  - Listen gælder i 14 dage.
- `SGAP_Generator::pick()` tager de prioriterede sider først, i Command Centers rækkefølge. Derefter
  følger den gamle regel: aldrig promoveret først, ellers længst siden.
  - En prioriteret side kan komme igen efter 7 dage. Den normale pause er `repost_cooldown_days`.
  - Dagens antal, køen, kanalerne, lofterne og kvalitetsgaten er uændrede.
- `source()` og `prompt()` tager søgeordet med. AI'en bruger det naturligt én gang og som hashtag,
  hvis det passer, uden at proppe det ind.
- `/snapshot` har `cc_priorities` (`received_at`, `active`, `due`), så Command Center kan se, hvad der
  kom frem.
- 13 nye smoke-checks (1 587 → 1 600 PASS, 0 FAIL).

## 7.81.1 — 2026-11-12

**Den gratis reserve prøver nu Nemotron Ultra først.**

### Ændret
- `SGAP_AI::FREE_MODELS` er nu `nvidia/nemotron-3-ultra-550b-a55b:free` → `google/gemma-4-31b-it:free` →
  `openrouter/free` (ejerens valg 12/11). Nemotron Ultra (550B) skrev det bedste gratis svar i testen
  fra sitet, mens Gemma ikke svarede, og `openrouter/free` valgte en model på 2,6B. Er Nemotron optaget,
  går OpenRouter selv videre ned ad listen.
- Smoke-checket for rækkefølgen er rettet (1 587 PASS, 0 FAIL).

## 7.81.0 — 2026-11-12

**Løber OpenRouter-kreditten tør, skriver autopiloten videre med en gratis model i stedet for at stå stille.**

### Tilføjet
- `SGAP_AI::free_retry()`: afviser OpenRouter den betalte model for manglende kredit (402, eller
  »requires more credits« / »can only afford«), prøver genereringen én gang til på gratis modeller med
  OpenRouters `models`-liste: `google/gemma-4-31b-it:free` og derefter `openrouter/free`, som er
  OpenRouters egen router over de gratis modeller. Målt fra steamgears.eu 12/11, mens den betalte model
  blev afvist (»can only afford 405 tokens«): `openrouter/free` svarede med `cost: 0`, og listen faldt
  videre til `nvidia/nemotron-3-ultra-550b-a55b:free` med brugbar tekst.
- Kvalitetsgaten bedømmer de gratis svar ligesom alle andre.
- Kører kun ved kreditfejl hos OpenRouter. 401, 404 og andre udbydere er uændrede. Nøgletestet og
  Content Studio er ikke berørt.
- Filteret `sgap_free_models` ændrer listen, og en tom liste slår reserven fra.
- Kørselsrapporten tæller `free` og `free_model`. Selvtjekket melder, når sider blev skrevet af den gratis
  model, så skiftet ikke er skjult.
- Fejler de gratis modeller også (fx dagsgrænsen for gratis kald), står begge grunde i fejlen.
- 9 nye smoke-checks (1 578 → 1 587 PASS, 0 FAIL).

## 7.80.0 — 2026-11-12

**Opslag til slukkede kanaler venter i køen i stedet for at blive "udgivet" ud i ingenting, AI-kaldet beder kun om de tokens det skal bruge, og selvtjekket siger til, når den seneste AI-kørsel ikke skrev noget.**

### Rettet
- `SGAP_Queue::claim()` frigav alle køens opslag, også til kanaler der er slukket under
  *Settings → Publer → Channels*. I RSS-tilstand blev de markeret `published` i et feed som Publer ikke
  læser. Målt på steamgears.eu 12/11: 22 opslag stod som udgivet på 7 slukkede kanaler. Nu frigives kun
  opslag til tændte kanaler. Påmindelser (`remind = 1`) er mail og går stadig ud. Uden nogen kanal i
  indstillingen filtreres der ikke, så intet fryses ved en fejl, og et REST-træk med en bestemt kanal
  er uændret.

### Ændret
- `SGAP_AI::token_budget()` sætter `max_tokens` til 1 500 + 700 pr. kanal (mindst 2 500, højst 8 000).
  Før var den fast 8 000 (chat completions) og 16 000 (Anthropic). OpenRouter reserverer kredit for hele
  `max_tokens` på forhånd, så en lav saldo afviste kald, der kun brugte en tiendedel. Med 3 kanaler er
  loftet nu 3 600.

### Tilføjet
- Selvtjekket (`SGAP_Auto::output_problems()`, en del af `health()`) melder to nye problemer:
  - Når den seneste AI-kørsel skrev 0 kladder og havde fejl, vises tidspunktet og den første fejl,
    fx manglende kredit. Før så man det først, når køen løb tør dage senere.
  - Når der står opslag i kø til slukkede kanaler, vises antallet pr. kanal (`SGAP_Queue::parked()`).
- 10 nye smoke-checks i `plugins/tests/smoke.php` (1 568 → 1 578 PASS, 0 FAIL).

## 7.79.0 — 2026-11-12

**Cirla kan nu gives til en rolle der kun har Cirla — uden at give rollen hele sitet — og en afvist handling svarer med en fejlkode i stedet for en exception.**

### Rettet
- `SGAP_Cirla::map_cap()` sendte `sgap_cirla_run` videre til `manage_options` uanset hvad, så en
  begrænset rolle (fx redaktør med kun `read` + `sgap_cirla_run`) blev afvist med 403, selv om rollen
  havde capabilityen. Målt på steamgears.eu 11/11: `current_user_can('sgap_cirla_run')` var `false` for
  en rolle med kun de to rettigheder, mens administrator var `true`. Nu vinder en direkte tildeling
  (`['exist']`), og uden den går capabilityen stadig gennem `manage_options`, så administratorer er
  uændrede. Det er forudsætningen for C7 i `projektstatus.json` (Cirla-bruger med begrænset rolle).
- `SGAP_Cirla::seo_check()` og `social_suggestions()` var deklareret `: array`, men returnerer
  `WP_Error` når modulet er slukket, rettigheden mangler eller det daglige loft er brugt. Målt på
  steamgears.eu 11/11 gav et social-kald med brugt budget **»Return value must be of type array,
  WP_Error returned«** i stedet for 429. Begge er nu `array|WP_Error`, så 403/409/429 når klienten
  som tilsigtet.
- 6 nye smoke-checks i `plugins/tests/cirla.php` (1 550 → 1 556 PASS, 0 FAIL).

## 7.76.1 — 2026-11-12

**REST-datoer, falske boolske felter og oprydningen efter pluginnet er rettet.**

### Rettet
- `scheduled_at` er site-wall-clock, ikke et tidspunkt: en lokal `2026-12-25 10:00` blev sendt gennem
  `strtotime()`/`wp_date()` og flyttet med sitets UTC-offset; `2026-02-31` blev normaliseret til en anden dag.
  `SGAP_Queue::schedule()` validerer nu dato og tid og bevarer værdien; en umulig dato giver **400** i REST i
  stedet for at falde tilbage til “nu”.
- `force=false` og `remind=false` blev læst som sande, fordi `(bool) "false"` er true. `SGAP_REST::flag()`
  accepterer kun `true`, `1`, `yes` og `on`; et form-request kan ikke længere omgå quality-gaten eller sende en
  reminder som en almindelig post.
- `POST /drafts/<id>/status` svarede **200** på et ukendt id. Den slår id op først og svarer **404**.
- `POST /queue/<id>/status` accepterer nu `status=queued`; det genbruger `SGAP_Queue::retry()` og nulstiller
  attempts, error, external id og reminder. Admin-knappen bruger samme metode.
- Kvalitetsgaten behandlede **enhver** query-streng som et arkiv. Nu er kun rigtige arkiv-parametre (`s`,
  `paged`, `page`, `orderby`, …) arkiver; `?utm_source=…` og `?p=123` går gennem linkkontrollen.
- Uninstall sletter nu alle `_sgap_*`-postmeta via `LIKE` og rydder også `sgap_evergreen`, `sgap_coach_learn`,
  `sgap_rescue` og `sgap_cirla_daily`. `SGAP_Install::TABLES` og `/snapshot` kender `sgap_publish_log` og
  `sgap_reddit_posts`.

### Målt
- 12 nye smoke-checks (1550 → **1562 PASS**, 0 FAIL); `php -l` på de ændrede filer. Ingen live- eller
  integrationstest i denne kørsel — releasen kræver ejerens *Plugins → Update*.

## 7.76.0 — 2026-11-11

**OpenRouter er standard, billeder kan laves via OpenRouter, og »Log ind i Command Center« logger ind med ét klik (P10).**

### Tilføjet
- `includes/openrouter.php`: en advarsel på pluginnets sider, mens AIMLAPI er valgt, og knappen
  **Switch to OpenRouter now**, når OpenRouter-reserven har nøgle og model. Den gør OpenRouter til
  hovedudbyder med præcis den nøgle og model; AIMLAPI-nøglen røres ikke.
- Indstillingen **OpenRouter image model** (*Settings → AI content*). Med en OpenRouter-nøgle (hoved eller
  reserve) laves billeder via OpenRouter (`chat/completions`, `modalities: image`, data-URL); uden den bruges
  AIMLAPI som før. Ingen standardmodel, fordi OpenRouters katalog skifter.
- `POST /sgap/v1/cc-link` (kræver `manage_options`): Command Center 7.27+ lægger sin adresse og en fælles
  nøgle her (option `sgap_cc_link`, ikke autoload). Knappen **Log ind i Command Center** laver en
  HMAC-SHA256-billet (60 s, 128-bit `jti`) og sender browseren til `{Command Center}/cc-sso`.

### Ændret
- OpenRouter er standardudbyder, når intet er gemt, og står først og anbefalet i guiden, indstillingerne og
  nøglesiden. AIMLAPI er markeret *being phased out*; et gemt AIMLAPI-valg virker stadig.
- Uden forbindelse fra Command Center hedder knappen **Open Command Center** og åbner adressen fra
  indstillingerne som før.

### Rettet
- Command Centers gamle engangslink sendte til `POST /sgap/v1/login-link`, en rute pluginnet aldrig har haft,
  så knappen i Command Center kunne ikke virke. Den nye vej erstatter den.

### Målt
- `plugins/tests/cc-login.php`: 45 nye checks (billet, signatur, udløb, rettigheder, ruten, billed-backend og
  flytte-knappen). Nøglen står hverken i status, snapshot, knappens HTML eller billetten.

## 7.75.0 — 2026-11-11

**Log-rækkerne på Cirla-siden siger nu hvad målet hedder, ikke kun hvor det ligger.**

### Tilføjet
- `SGAP_Cirla::pending_draft($id)` svarer på begge spørgsmål i én query: findes kladden stadig under
  AI Drafts, og hvad hedder den. `draft_exists()` bygger nu på den, så der er **én** eksistens-kontrol.
- En *draft*-række læses som **»Draft #7 · Brass goggles«** med link til den konkrete kladde
  (`#sgap-draft-7`); en *seo*- eller *social*-række læses som **»SEO check · sidens titel«** /
  **»Suggestions · sidens titel«** med link til sidens editor.
- `SGAP_Cirla_Admin::row_target()` giver url og titel samlet, så de to altid følges ad;
  `row_url()` er bevaret som tynd wrapper.

### Sikkerhed mod døde links
- Titel og link kommer fra samme kontrol: en kladde der er godkendt, afvist eller slettet, en slettet
  side, en gammel række uden id og en række uden naturligt mål giver **hverken** link **eller** titel —
  rækken står som ren tekst med sit oprindelige resultat.
- Titel og resultat escapes ved rendering, så en kladdetitel med markup ikke bliver HTML.
- Filteret fra 7.73.0 og begge tomme tilstande er uændrede.

### Målt
- Smoke: **1 505 PASS, 0 FAIL** (1 504 → 1 505; link- og titel-checks omskrevet, én ny).
  `php -l` rent, fejlscan uden fund.

## 7.74.0 — 2026-11-11

**Log-rækkerne på Cirla-siden peger nu på det de handler om.**

### Tilføjet
- `SGAP_Cirla::log($action, $result, $meta)` gemmer id'et på den kladde eller side rækken handler om,
  så loggen kan bruges som indgang og ikke kun som historik.
- En *draft*-række linker til kladden på **AI Drafts** (`admin.php?page=sgap-ai#sgap-draft-<id>`); hver
  kladde har fået et anker i `includes/core.php`.
- En *seo*- eller *social*-række linker til sidens editor.
- `SGAP_Cirla::draft_exists()` er nu offentlig og dokumenteret; den svarer kun ja for kladder der stadig
  venter under AI Drafts.

### Sikkerhed mod døde links
- Der linkes kun når målet stadig findes: en kladde der er godkendt, afvist eller slettet, og en side der
  er slettet, giver **ingen** link — rækken står som ren tekst. Gamle rækker uden id og rækker uden
  naturligt mål (status, cron, toggle) er også ren tekst.
- Filteret fra 7.73.0 og begge tomme tilstande er uændrede.

### Målt
- 8 nye smoke-checks (1 496 → 1 504 PASS, 0 FAIL), `php -l` rent, fejlscan uden fund.

## 7.73.0 — 2026-11-11

**Loggen på Cirla-siden kan ses én handling ad gangen.**

### Tilføjet
- `SGAP_Cirla::entries($limit, $action)` kan nu læse én handling; uden filter er svaret som før.
- Faner øverst i log-kortet — *All*, *Read the status*, *Write one draft*, *Run the SEO check*,
  *Suggest social posts* — med antal rækker i hver, så det er synligt hvor loggen har noget at vise.
  Den valgte fane er tekst med `aria-current="page"`, de andre er links (`?page=sgap-cirla&cirla_log=draft`).
- Ukendte eller opdigtede filtre falder tilbage til *All* i stedet for at give en tom side.

### Bevaret
- Den oprindelige tomme tilstand, når loggen slet ikke har rækker.
- En ny tom tilstand for et filter uden rækker: »No *Write one draft* rows in the last 20« med et link
  tilbage til alle rækker.

### Målt
- 6 nye smoke-checks (1 490 → 1 496 PASS, 0 FAIL), `php -l` rent, fejlscan uden fund.

## 7.72.0 — 2026-11-11

**Cirla har fået sin egen side i Steamgears-menuen — den kan bruges uden MCP.**

### Tilføjet
- `modules/cirla/class-cirla-admin.php`: en Cirla-side under **Create** med modulets tilstand (til/fra, næste
  daglige job, AI-budget brugt i dag, kladder under AI Drafts), de fire handlinger som knapper og modulets log.
  Siden indlæses kun sammen med modulet, så et slukket modul ikke har en side.
- Knapperne kalder præcis de samme funktioner som abilities (`status`, `draft`, `seo_check`,
  `social_suggestions`) via `admin-post.php` med nonce og `manage_options`, viser resultatet som en tabel og
  redirecter tilbage — en genindlæsning kører ikke handlingen igen.
- Emne, kanal, side-id og antal forslag valideres og saniteres i `SGAP_Cirla_Admin::input()`, så siden ikke
  kan sende noget abilities ikke også ville acceptere.

### Målt
- 15 nye smoke-checks (1 475 → 1 490 PASS, 0 FAIL), `php -l` rent, fejlscan uden fund, zip byte-identisk.

## 7.71.2 — 2026-11-11

**Cirla svarer nu med de rigtige HTTP-statuskoder — målt på et rigtigt WordPress.**

### Rettet
- Alle 13 `WP_Error` i modulet bærer `['status' => …]`, som resten af plugin'et gør: dagligt loft **429**,
  kvalitetsgate **422**, slukket modul **409**, manglende rettighed **403**, dårligt input **400**, ukendt
  indhold **404** og gemmefejl **500**. Før blev et budgetafslag og en gate-blokering sendt som HTTP 500,
  så en klient ikke kunne se forskel på «din kvote er brugt» og «serveren fejlede».
- Fundet ved at køre modulet på en rigtig WordPress-installation, ikke i sandkassen.

### Målt
- WordPress 7.1.4 med SQLite-driver, plugin installeret fra zip: kvalitetsgaten blokerede linket til en kladde
  (500 → **422**, ingen ny række), det daglige loft stoppede kald 6 (500 → **429**), en subscriber blev afvist
  (**403**), og et slukket modul gav **404** på ability-ruten. Bevis:
  `docs/library/cirla-wordpress-roegtest-2026-11-11.md`.

## 7.71.1 — 2026-11-11

**Patch notes er nu en fast del af hver udgivelse.** Ingen PHP-adfærd er ændret.

### Tilføjet
- `CHANGELOG.md` i pluginnet: patch notes for 7.65.0 og frem, og fra nu af en note ved hver version.
- `tools/patch_notes.py`: `--check` (nyeste note matcher versionen, ingen huller i historikken),
  `--latest` (noten klar til svaret), `--version X` og `--selftest` med fixtures.
- Værnet kører i `tools/natlige-vaern.sh` og i `tools/release.py --check --guards`.
- Regel i AGENTS.md §7.4: en version uden patch note er ikke en udgivelse.

### Målt
- `php -l`, smoke og `fejlscan` uændret grønne; zip'en er genopbygget med `CHANGELOG.md` i og er
  byte-identisk med kilden.

## 7.71.0 — 2026-11-10

**P9: Cirla er et modul, der kan slås til og fra, og som er slukket som standard.**

### Tilføjet
- `modules/cirla/class-cirla.php` indlæses kun, når `sgap_cirla_enabled` er `yes` — slået fra betyder
  ingen klasse, altså ingen ability og intet cron-job.
- Fire handlinger bag capabilityen `sgap_cirla_run`: `cirla-status`, `cirla-draft`, `cirla-seo-check`
  og `cirla-social-suggestions`.
- Dagligt AI-loft (`sgap_cirla_daily_calls`, standard 5), modul-log, dagligt cron-job og filteret
  `sgap_cirla_generate`; indstillingerne ligger under *Settings & keys → Cirla*.
- En kladde gemmes som `pending` i `sgap_ai_drafts` med `angle = cirla` — den køes eller publiceres aldrig.

### Målt
- 1 471 PASS / 0 FAIL (28 nye checks), fra → til → fra igen, `php -l` rent, fejlscan uden fund, zip
  byte-identisk.

## 7.70.1 — 2026-11-10

**OpenRouter-headeren bygges nu ét sted — den der blev testet, er den der bliver sendt.**

### Rettet
- `SGAP_AI::bearer()` renser tokenet (linjeskift og usynlige tegn inde i værdien fjernes) i stedet for
  kun `trim()`.
- `openrouter_headers()` / `openrouter_post()` er nu den eneste vej til `/chat/completions` for
  nøgletest, failover og generator.
- `stripped_by()` kører sitets eget `http_request_args`-filter på en kopi af requesten, så et plugin der
  fjerner headeren bliver navngivet i stedet for at sende ejeren til `openrouter.ai/keys`.

### Målt
- 11 nye smoke-checks ser på de argumenter plugin'et giver WordPress' HTTP-lag; med `bearer()` sat tilbage
  til `trim()` fejler 4 af dem. 1 443 PASS / 0 FAIL.

## 7.70.0 — 2026-11-10

**P8: agenterne læser sidens målte tal i stedet for en fast antagelse.**

### Tilføjet
- `SGAP_Coach`: et målt brief fra `sgap_events`, kladdebeholdningen og WordPress' egne tællinger går ind i
  prompten hos den daglige forfatter, kampagne-agenten, Studio-artiklen og Studio-SEO-redaktøren.
- Dagligt cron der omsætter tallene til højst 12 daterede regler med bevis (25+ klik, 14+ dage uden
  publicering, 20+ ventende kladder).
- Read-only ability `agent-brief` og et kort på dashboardet; `tools/agent_brief.py` måler det levende
  katalog og skriver `docs/agent-brief.md`, som `seo_agent.py` læser før den planlægger.

### Målt
- 44 nye coach-checks (1 383 → 1 427 PASS, efter rebase 1 432), 13 Python-tests, fejlscan uden fund.

## 7.69.1 — 2026-11-10

**Nøgletesten siger nu hvad der er galt med nøglen.**

### Rettet
- Formen tjekkes før der bruges en request: en OpenRouter-nøgle skal starte med `sk-or-v1-`; alt andet
  navngives med sin længde og en henvisning til `openrouter.ai/keys`.
- `SGAP_AI::api_key()` trimmer nøglen for generator, Studio, AI Chat og nøgletest, så et linjeskift fra en
  indsættelse ikke ødelægger Bearer-tokenet.

### Målt
- 5 nye smoke-checks (1 432 → 1 437 PASS).

## 7.69.0 — 2026-11-10

**P7: RSS-tilstanden kan måles — »kan kanalen sende?« og »har dens feed noget brugbart?«**

### Tilføjet
- `SGAP_RSS::health()` giver hver konfigureret kanal én tilstand: `ok`, `empty`, `stale` (ældre end 7
  dage, filter `sgap_feed_stale_days`), `invalid` (post uden titel/tekst/foto hvor Instagram og Pinterest
  kræver det) eller `off` (API-tilstand) — med antal poster, alder og feed-adresse.
- `health_summary()` tæller tilstandene og navngiver de kanaler der kræver handling; felterne
  `feeds`/`feeds_summary` ligger i abilityen `channel-health` og i `/sgap/v1/channel-health`.

### Målt
- 89 checks i `plugins/tests/feed-health.php`, ingen ny tabel, indstilling eller side.

## 7.68.0 — 2026-11-10

**P6: kampagne-agenten skriver kladder, men publicerer aldrig.**

### Tilføjet
- `SGAP_Campaign_Agent`: en publiceret side, et skrevet mål (8–160 tegn) og de konfigurerede kanaler giver
  ét udkast pr. kanal — altid `pending` i `sgap_ai_drafts`, også med Full Auto slået til. Agenten kalder
  hverken `SGAP_Queue` eller `SGAP_Publer`.
- To nye kolonner: `gate_report` bærer preflightens og kvalitetsgatens fund med kladden, og `campaign`
  følger kladden gennem `from_draft()` til `utm_campaign`.
- Abilityen `campaign-drafts` og et dashboardkort med formular.

### Målt
- 42 nye smoke-checks (1 316 → 1 358 PASS).

## 7.67.1 — 2026-11-10

**P1.24: OpenRouter som automatisk backup for AIMLAPI.**

### Tilføjet
- Backuppen har sin egen nøgle og sit eget model-felt, så en rotation af den ene ikke peger backuppen på
  den anden.
- Kun udbyderfejl starter den (transport, 401/403, 402, 429, 5xx); et 2xx-svar gør aldrig, heller ikke når
  det er tomt eller afkortet. 400/404/422 rapporteres uændret som vores egen fejl.
- `SGAP_AI::chat_completions()` er nu den eneste vej til `/chat/completions`, så generator, Content Studio
  og AI Chat deler samme failover; hver failover giver én række i fejlloggen og en sætning i chat-svaret.

### Målt
- 30 nye smoke-checks (1 286 → 1 316 PASS). Live er intet målt — der findes ingen OpenRouter-nøgle i
  sandkassen.

## 7.67.0 — 2026-11-09

**P1.23: OpenRouter som egen tekst-provider.**

### Tilføjet
- `openrouter` er et eget valg: adressen er fast (`SGAP_AI::OPENROUTER_URL`), og `base_url()` ignorerer det
  håndskrevne felt for den provider.
- `SGAP_KeyCheck::check_openrouter()` beviser nøglen med ét token mod den valgte model og skelner afvist
  nøgle (401/403), tom konto (402), ukendt model (404/400) og rate limit (429).
- Ingen standardmodel: kataloget læses fra `/models` og caches under `sgap_ai_catalog_openrouter`, som
  ryddes ved rotation.

### Målt
- 9 nye smoke-checks (1 277 → 1 286). Alle kald er mocket — ingen nøgle findes i sandkassen.

## 7.66.0 — 2026-11-09

**P5: forum og Reddit som trafikaccelerator.**

### Tilføjet
- Tråde som CPT med native kommentarer og `DiscussionForumPosting`; svar kræver login, nonce og honeypot,
  højst 3 tråde i timen, og alt fra ikke-moderatorer lander som `pending`.
- Reddit får kun link posts gennem en egen kø: 2 i døgnet, 90 minutters interval og 5 → 15 → 45 minutters
  backoff, med `utm_source=reddit` og `utm_campaign=<tavle>`; tråden fører videre til produkter gennem `/go/`.
- Radar der læser hot i op til fem subreddits og rangerer `score + 2 × kommentarer`. Modulet kommenterer
  aldrig selv.

### Målt
- 1 277 PASS / 0 FAIL, `php -l` rent på 67 filer, zip byte-identisk. Intet er kaldt mod Reddit endnu;
  klienten er testet gennem transport-seamet.

## 7.65.5 — 2026-11-09

**S5.8: backup og gendannelse øvet — kun versionsnummeret er ændret i plugin-filen.**

### Ændret
- `tools/wp_db_drill.py` dumper databasen med `mysqldump`, gendanner den under scratch-prefixet `sgtest_`
  og sammenligner rækkeantal pr. tabel: 269 af 269 tabeller identiske, RTO 6 s, intet tilbage.

## 7.65.4 — 2026-11-09

**Femten inline side-scripts er blevet syv filer og et localize-objekt.**

### Ændret
- Syv filer i `assets/pages/` (dashboard, studio, seo, chat, tools, niche, setup) enqueues af
  `SGAP_Assets::page_script()` med filens mtime som version; konfigurationen sendes med
  `wp_localize_script`, så nonces, chat-historik og værktøjskatalog stadig beregnes pr. request.
- `site-seo`-ens nowdoc blev sin egen fil, og `script()` er væk. Det ene `<script>` tilbage i `includes/`
  er JSON-LD, som er data.

### Målt
- JS-teksten er byte-identisk med det HEAD printede (kontrolleret for alle syv filer) og `node --check`-ren.

## 7.65.3 — 2026-11-09

**Dokumentations-patch: §8 pkt. 8 og changelog.**

### Ændret
- Kun versionsnummer og dokumentation; zip'en blev genopbygget fra den merged kilde, så den matcher træet.

## 7.65.2 — 2026-11-08

**Admin-UI: CSS og JS ud af `<head>` — 41,8 KB mindre pr. side.**

### Ændret
- Fire filer i `assets/` enqueues af `SGAP_Assets`: menu-assets overalt, side-assets kun på pluginets egne
  skærme (`is_plugin_screen()`), begge kun for `manage_options`. Versionen er filens mtime, så en
  CSS-rettelse ikke serveres fra cachen.
- UI: `:focus-visible` på alle kontroller, scrollbare tabeller under 782 px, ét-kolonne-grid og mindre
  padding på mobil, `prefers-reduced-motion` slukker animationer, og tal står i `tabular-nums`.

### Målt
- 36 nye smoke-checks i `plugins/tests/assets.php` (1 172 PASS / 0 FAIL).

## 7.65.1 — 2026-11-08

**Dokumentations-patch: roadmap-måling og tretten ejerpunkter navngivet.**

### Ændret
- Kun versionsnummer og dokumentation; ingen pris, produkt, gateway, zone, Complianz-indstilling eller
  kanal-token blev rørt.

## 7.65.0 — 2026-11-08

**Kø-siden viser sprog og kilde.**

### Tilføjet
- En `Language`-kolonne med sproget og original/translation samt en `Source`-kolonne, der linker en
  oversættelse til den kø-post den kom fra og viser dens titel; hver række har fået et id, så linket
  hopper direkte til originalen.
- Ét opslag med self-join på `source_id`; en slettet kilde viser sit id i stedet for et gæt, og titler
  escapes som alle andre felter.

### Målt
- 8 nye smoke-checks i `plugins/tests/queue-page.php` (1 128 → 1 136 PASS).
