<?php
/**
 * AI editor (7.83.0): a second opinion on every generated post before it may reach the queue.
 *
 * The quality gate (quality.php) checks rules: banned words, links, alt text, duplicates. It cannot
 * read. The editor does: one request per page to OpenRouter's free models judges all of the page's
 * posts against the page they promote and scores each 0-10. Below MIN_SCORE the draft is rejected
 * with the reason. When no editor answers, Full auto does not queue the posts: they wait under
 * AI Drafts for a person, because "nobody checked it" is not the same as "it is fine".
 * Costs nothing: only `:free` models are asked.
 */
if (!defined('ABSPATH')) {
    exit;
}

class SGAP_Editor {
    const MIN_SCORE = 7;
    /**
     * Free text models, in order; OpenRouter walks the list itself when one is busy. OpenRouter
     * refuses more than 3 (measured live 12/11: "'models' array must have 3 items or fewer").
     */
    // 7.87.0: Super first. Ultra did not answer within 52 s on 14/11, while Super answered in about 20 s.
    const MODELS = ['nvidia/nemotron-3.5-super-vl:free', 'nvidia/nemotron-3-ultra-550b-a55b:free', 'openrouter/free'];
    const MAX_MODELS = 3;
    /** 7.86.0: held drafts are asked again on the hourly job for this many days, then they wait for a person. */
    const RETRY_DAYS = 3;
    /** Pages (one editor request each) per hourly run, so a backlog cannot flood the free models. */
    const RETRY_PAGES = 5;
    /** Notes that mean "no editor answered" (see verdict()). Only these drafts are asked again. */
    const HELD_NOTES = ['Editor: not checked%', 'Editor: no score%'];
    const LAST_RETRY = 'sgap_editor_rereview';

    public static function init(): void {
        add_action(SGAP_Rescue::CRON, [__CLASS__, 'rereview'], 20);
    }

    public static function min_score(): int {
        return max(0, min(10, (int) apply_filters('sgap_editor_min_score', self::MIN_SCORE)));
    }

    /** @return string[] */
    public static function models(): array {
        return array_slice(array_values(array_filter(array_map('strval', (array) apply_filters('sgap_editor_models', self::MODELS)))), 0, self::MAX_MODELS);
    }

    /** On when an OpenRouter key exists and the model list is not emptied by the filter. */
    public static function enabled(): bool {
        return SGAP_AI::api_key() !== '' && self::models() !== [];
    }

    public static function prompt(array $posts, array $source): string {
        $items = [];
        foreach ($posts as $p) {
            $items[] = ['channel' => (string) ($p['channel'] ?? ''), 'title' => (string) ($p['title'] ?? ''),
                'text' => (string) ($p['text'] ?? ''), 'hashtags' => array_values((array) ($p['hashtags'] ?? []))];
        }
        return "You are a strict social media editor for steamgears.eu, a steampunk shop. Score each post 0-10.\n"
            . "Deduct hard for: facts, prices, discounts, shipping promises or guarantees that are NOT in the page below; "
            . "generic AI filler and cliches (\"elevate\", \"unlock\", \"in today's world\", \"delve\"); repeating the same "
            . "opening across channels; broken or mixed language; hashtag or keyword stuffing; wrong tone for the channel; "
            . "anything misleading or offensive. 8+ only if you would post it on the shop's account as it is.\n"
            . 'Answer JSON only: {"reviews": [{"channel": "...", "score": <0-10>, "problems": ["..."]}]}' . "\n\n"
            . "PAGE: " . (string) ($source['title'] ?? '') . "\n" . mb_substr((string) ($source['summary'] ?? ''), 0, 2500) . "\n\n"
            . "POSTS:\n" . wp_json_encode($items);
    }

    /**
     * @return array{ok:bool, by_channel?:array<string,array{score:float,problems:string[]}>, model?:string, error?:string}
     */
    public static function review(array $posts, array $source): array {
        if (!self::enabled()) {
            return ['ok' => false, 'error' => 'no OpenRouter key for the editor'];
        }
        $models = self::models();
        // The free models reason first: 1 200 tokens were all spent thinking (finish_reason=length,
        // measured live 12/11); 4 000 leaves room for the answer. Free models cost nothing per token.
        $body = ['model' => $models[0], 'models' => $models, 'max_tokens' => 4000,
            'messages' => [['role' => 'user', 'content' => self::prompt($posts, $source)]]];
        // 7.92.1: same path as the writer, so a short balance gets the one lower-max_tokens retry too.
        $decoded = SGAP_AI::chat_completions(SGAP_AI::api_key(), $body, 90, 'Editor');
        if (is_wp_error($decoded)) {
            return ['ok' => false, 'error' => $decoded->get_error_message()];
        }
        $text = (string) ($decoded['choices'][0]['message']['content'] ?? '');
        if (!preg_match('/\{.*\}/s', $text, $m)) {
            return ['ok' => false, 'error' => 'the editor answered without JSON'];
        }
        $data = json_decode($m[0], true);
        $out = [];
        foreach ((array) ($data['reviews'] ?? []) as $r) {
            $channel = sanitize_key((string) ($r['channel'] ?? ''));
            $score = $r['score'] ?? null;
            if ($channel === '' || !is_numeric($score) || $score < 0 || $score > 10) {
                continue;
            }
            $out[$channel] = ['score' => round((float) $score, 1),
                'problems' => array_slice(array_map(fn($p) => mb_substr(sanitize_text_field((string) $p), 0, 160), (array) ($r['problems'] ?? [])), 0, 5)];
        }
        if (!$out) {
            return ['ok' => false, 'error' => 'the editor gave no usable scores'];
        }
        return ['ok' => true, 'by_channel' => $out, 'model' => (string) ($decoded['model'] ?? $models[0])];
    }

    /**
     * 7.86.0: asks the editor again about drafts that are pending only because no editor answered.
     * A score >= MIN_SCORE queues the draft in Full auto (it stays a draft otherwise), a low score
     * rejects it with the reason, and another silence leaves it pending for the next hour. Drafts a
     * person has already handled are never touched: only status `pending` with a held note counts, and
     * campaign drafts are left out (the campaign agent never queues).
     * @return array{pages:int, approved:int, queued:int, rejected:int, still_held:int, errors:string[]}
     */
    public static function rereview(): array {
        global $wpdb;
        $out = ['pages' => 0, 'approved' => 0, 'queued' => 0, 'rejected' => 0, 'still_held' => 0, 'errors' => []];
        if (!self::enabled()) {
            return $out;
        }
        $table = $wpdb->prefix . 'sgap_ai_drafts';
        $since = gmdate('Y-m-d H:i:s', (int) current_time('timestamp') - self::RETRY_DAYS * DAY_IN_SECONDS);
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, post_id, channel, title, body, hashtags FROM {$table} WHERE status = 'pending' AND created_at >= %s"
            . " AND (gate_report LIKE %s OR gate_report LIKE %s) AND (campaign IS NULL OR campaign = '')"
            . " ORDER BY created_at ASC, id ASC LIMIT 100",
            $since, self::HELD_NOTES[0], self::HELD_NOTES[1]
        ), ARRAY_A);
        $by_page = [];
        foreach ((array) $rows as $row) {
            $by_page[(int) $row['post_id']][] = $row;
        }
        $full_auto = SGAP_Settings::enabled('full_auto_enabled');
        foreach (array_slice($by_page, 0, self::RETRY_PAGES, true) as $post_id => $drafts) {
            $post = get_post($post_id);
            if (!$post instanceof WP_Post) {
                continue;
            }
            $out['pages']++;
            $posts = array_map(fn($d) => ['channel' => (string) $d['channel'], 'title' => (string) $d['title'], 'text' => (string) $d['body'],
                'hashtags' => array_values(array_filter(preg_split('/\s+/', (string) $d['hashtags']) ?: []))], $drafts);
            $review = self::review($posts, SGAP_Generator::source($post));
            foreach ($drafts as $d) {
                $verdict = self::verdict($review, (string) $d['channel']);
                if ($verdict['action'] === 'hold') {
                    $out['still_held']++;
                    continue;
                }
                // Claim the row: a person may have edited or used it while the editor was thinking.
                $claimed = $wpdb->query($wpdb->prepare(
                    "UPDATE {$table} SET gate_report = %s, status = %s WHERE id = %d AND status = 'pending'",
                    $verdict['note'] . ' (asked again)', $verdict['action'] === 'reject' ? 'rejected' : 'pending', (int) $d['id']
                ));
                if (!$claimed) {
                    continue;
                }
                if ($verdict['action'] === 'reject') {
                    $out['rejected']++;
                    continue;
                }
                $out['approved']++;
                if ($full_auto) {
                    $queued = SGAP_Queue::from_draft((int) $d['id']);
                    if (is_wp_error($queued)) {
                        $out['errors'][] = $queued->get_error_message();
                    } else {
                        $out['queued']++;
                    }
                }
            }
        }
        if ($out['pages'] > 0) {
            update_option(self::LAST_RETRY, ['at' => current_time('mysql')] + $out, false);
            delete_transient('sgap_dashboard_stats');
        }
        return $out;
    }

    /**
     * What happens to one post: 'approve' (may be queued), 'reject' (stored as rejected) or 'hold'
     * (stored as pending, never queued automatically). Plus the line for the draft's gate report.
     * @return array{action:string, note:string}
     */
    public static function verdict(array $review, string $channel): array {
        if (!$review['ok']) {
            return ['action' => 'hold', 'note' => 'Editor: not checked (' . mb_substr((string) ($review['error'] ?? ''), 0, 120) . ') – waits for you.'];
        }
        $r = $review['by_channel'][$channel] ?? null;
        if ($r === null) {
            return ['action' => 'hold', 'note' => 'Editor: no score for this channel – waits for you.'];
        }
        $line = 'Editor: ' . $r['score'] . '/10' . ($r['problems'] ? ' – ' . implode('; ', $r['problems']) : '');
        return ['action' => $r['score'] >= self::min_score() ? 'approve' : 'reject', 'note' => $line];
    }
}
